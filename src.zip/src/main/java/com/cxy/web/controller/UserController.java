package com.cxy.web.controller;

import com.cxy.domain.User;
import com.cxy.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/user")
@ResponseBody
public class UserController {
    @Autowired
    private IUserService userService;
/*
@ResponseBody 把数据转成json格式响应
 */
    /*
    查询所有
     */
    //public @ResponseBody List<User> findAll() 在上面写，下面就不用写了
    @RequestMapping("/findAll")
     public List<User> findAll(){
        System.out.println("test");
        return userService.findAll();
    }
    /*
    根据id查询
     */
    @RequestMapping("/findById")
    public User findById(Integer id){
        return userService.findById(id);
    }
    /*
    更新
     */
    @RequestMapping("/updateUser")
    public void updateUser(@RequestBody User user){
        System.out.println(user);
        userService.updateUser(user);
    }
}
